
public interface BinaryTreeADT<T> {
  
  public boolean isEmpty();
  public void inOrderTraversal(); //does inorder traversal of a BT
  public void preOrderTraversal();  //does preorder traversal of BT
  public void postOrderTraversal();  //does postorder traversal of BT
  public int treeHeight();           //determines height of BT
  public int treeNodeCount();        //finds number of nodes in a BT
  public int treeLeavesCount();      //finds number of leaves in BT
  public void destroyTree();          //destroys a BT
  public boolean search(T item);     //determines whether item is in BT
  public void insert(T item);        //inserts item in BT
  public void delete(T item);        //deletes item from BT
  
}
