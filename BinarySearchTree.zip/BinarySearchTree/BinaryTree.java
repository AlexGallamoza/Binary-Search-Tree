
public abstract class BinaryTree<T> implements BinaryTreeADT<T> {
  //Definition of BinaryTreeNode class
  protected class BinaryTreeNode<T>{
    public T info;
    public BinaryTreeNode<T> lLink;
    public BinaryTreeNode<T> rLink;
    
    //Default constructor
    public BinaryTreeNode(){
      info = null;
      lLink = null;
      rLink = null;
    }
    public BinaryTreeNode(T item){
      info = item;
      lLink = null;
      rLink = null;
    }
    
    public String toString(){
      return info.toString();
    }
  }
  
  //Instance variable for class BinaryTree
  protected BinaryTreeNode<T> root;
  
  //Default constructor
  public BinaryTree() { 
    root = null;
  }
  
  public boolean isEmpty(){
    return (root == null);
  }
  
  public void inOrderTraversal(){
    inOrder(root);
  }
  //helper method called by inOrderTraversal
  private void inOrder(BinaryTreeNode<T> t){
    if(t!=null){
      inOrder(t.lLink);
      System.out.print(t.info + " ");
      inOrder(t.rLink);
    }
  }
  
  public void preOrderTraversal(){
    preOrder(root);
  }
  //helper method called by preOrderTraversal
  private void preOrder(BinaryTreeNode<T> t){
    if(t!=null){
      System.out.print(t.info + " ");
      preOrder(t.lLink);
      preOrder(t.rLink);
    }
  }
  
  public void postOrderTraversal(){
    postOrder(root);
  }
  //helper method called by postOrderTraversal
  private void postOrder(BinaryTreeNode<T> t){
    if(t!=null){    
      postOrder(t.lLink);
      postOrder(t.rLink);
      System.out.print(t.info + " ");
    }
  }
  
  
  public int treeHeight(){
    return height(root);
  }
  //helper method called by postOrderTraversal
  private int height(BinaryTreeNode<T> t){
    if(t==null)
      return 0;
    else if(t.lLink == null && t.rLink == null)
      return 0;
    else
      return 1 + Math.max(height(t.lLink), height(t.rLink));
  }
  
  
  //method to count # of nodes in a BT
  public int treeNodeCount(){
    return nodeCount(root);
  }
  //helper method called by treeNodeCount
  private int nodeCount(BinaryTreeNode<T> t){
    if(t == null) return 0;
    return nodeCount(t.lLink) + nodeCount(t.rLink) + 1;
  }
  
  
  //method to count # of leaves in BT
  public int treeLeavesCount(){
    return leavesCount(root);
  }
  //helper method called by treeLeavesCount
  private int leavesCount(BinaryTreeNode<T> t){
    if(t == null) return 0;
    if(t.lLink == null && t.rLink == null) return 1;
    return leavesCount(t.lLink) + leavesCount(t.rLink);
  }
  

  
  public void destroyTree(){
    root = null;
  }
  
  
  
  //method to determine whether a BT is a BST
  public boolean isBinarySearchTree(){
    return isBST(root);
  }
  //helper method called by isBinarySearchTree
  public boolean isBST(BinaryTreeNode<T> tree){
    if(tree==null) return true;
    Comparable<T> temp = (Comparable<T>)tree.info;
    if(tree.lLink != null && temp.compareTo(tree.lLink.info) < 0) return false;
    if(tree.rLink != null && temp.compareTo(tree.rLink.info) > 0) return false;
    return isBST(tree.lLink) && isBST(tree.rLink);
  }
  
  
  
  /*method to determine whether shapes of to trees are the same(nodes don't have to 
   contain same values, but each node must have same # of children)*/
  public boolean similarTrees(BinaryTreeNode<T> otherTree){
    return similar(root, otherTree);
  } 
  //helper method called by similarTrees
  public boolean similar(BinaryTreeNode<T> tree1, BinaryTreeNode<T> tree2){
    if(tree1 == null && tree2 == null) return true;
    if(tree1 != null && tree2 != null) return false;
    if(tree1 != null && tree2 == null) return false;
    if(tree1.info != tree2.info) return false;
    return similar(tree1.lLink, tree2.lLink) && similar(tree1.rLink, tree2.rLink);
  }
  
  
  

  
  
  
  
  //abstract methods 
  public abstract boolean search(T item);
  public abstract void insert(T item);
  public abstract void delete(T item);
}
