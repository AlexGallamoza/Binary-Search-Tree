import java.util.*;
public class ClientBST {
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
    BinarySearchTree<Integer> bst = new BinarySearchTree<Integer>();
    BinarySearchTree<Integer> otherTree = new BinarySearchTree<Integer>();
    Integer num;
    System.out.print("Enter integers(999 to stop): ");
    num = input.nextInt();
    while(num!=999){
      bst.insert(num);
      num = input.nextInt();
      
    }
    if(bst.isBinarySearchTree())
      System.out.println("This is a Binary Search Tree.");
    else
      System.out.println("This is not a Binary Search Tree.");
    System.out.println("tree height: " + bst.treeHeight());
    System.out.println("tree node count: " + bst.treeNodeCount());
    System.out.println("tree leaves count: " + bst.treeLeavesCount());
    
    System.out.print("Enter value to search for: ");
    num = input.nextInt();
    if(bst.search(num))
      System.out.println(num + " was found in this tree");
    else
      System.out.println(num + " was not found in this tree");
    
    System.out.print("Inorder traversal: ");
    bst.inOrderTraversal();
    System.out.print("\nPreorder traversal: ");
    bst.preOrderTraversal();
    System.out.print("\nPostorder traversal: ");
    bst.postOrderTraversal();
    System.out.print("\nEnter value to be deleted from tree: ");
    num = input.nextInt();
    bst.delete(num);
    System.out.print("\nInorder traversal after removing " + num + ": ");
    bst.inOrderTraversal();
    System.out.print("\nPreorder traversal after removing " + num + ": ");
    bst.preOrderTraversal();
    System.out.print("\nPostorder traversal after removing " + num + ": ");
    bst.postOrderTraversal();
    System.out.println();

    
    

  }
  
  
  
}
